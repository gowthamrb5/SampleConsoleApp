﻿using System;
using System.IO;
using System.Linq;
using System.Timers;
using System.Xml.Linq;

namespace Caiso_US_temp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Timer oneHourTimer = new Timer(60000); // (3600000); // 1 hour in milliseconds
            oneHourTimer.Elapsed += OnOneHourElapsed;
            //oneHourTimer.Enabled = true;
            //oneHourTimer.AutoReset = true;
            oneHourTimer.Start();

            args = new string[]
            {
                DateTime.Now.ToString(),DateTime.Now.AddMinutes(5).ToString(),"test","test"
            };

            //Timer fifteenMinuteTimer = new Timer(120000); // 15 minutes in milliseconds
            //fifteenMinuteTimer.Elapsed += OnFifteenMinuteElapsed;
            //fifteenMinuteTimer.Start();

            //Timer fiveMinuteTimer = new Timer(120000); // 5 minutes in milliseconds
            //fiveMinuteTimer.Elapsed += OnFiveMinuteElapsed;
            //fiveMinuteTimer.Start();

            Console.ReadLine(); // Keep console open
        }

        static async void OnOneHourElapsed(object sender, ElapsedEventArgs e)
        {
            string InXML = File.ReadAllText(@"D:\Code\Test\Caiso_US_temp\xml.txt");
            callfunction(InXML);
        }

        static void OnFifteenMinuteElapsed(object sender, ElapsedEventArgs e)
        {
            string InXML = File.ReadAllText(@"D:\Code\Test\Caiso_US_temp\xml.txt");
            callfunction(InXML);
            Console.WriteLine("Fifteen minutes elapsed");
            // Call your API here
        }

        static void OnFiveMinuteElapsed(object sender, ElapsedEventArgs e)
        {
            string InXML = File.ReadAllText(@"D:\Code\Test\Caiso_US_temp\xml.txt");
            callfunction(InXML);
            Console.WriteLine("Five minutes elapsed");
            // Call your API here
        }

        public async static void callfunction(string InXML)
        {
            // Load the XML string
            XDocument xdoc = XDocument.Parse(InXML);
            // Remove the XML declaration
            xdoc.Declaration = null;
            // Remove or change the xmlns attribute
            foreach (XElement element in xdoc.Descendants())
            {
                // Remove the namespace from element names
                if (element.Name.Namespace != XNamespace.None)
                {
                    element.Name = XNamespace.None.GetName(element.Name.LocalName);
                }

                // Remove namespace declarations from attributes
                element.ReplaceAttributes(
                    from attr in element.Attributes()
                    where !attr.IsNamespaceDeclaration
                    select attr
                );
            }

            // Get the modified XML string
            InXML = xdoc.ToString();
            await DBService.CallProcedure(InXML);
            Console.WriteLine("One hour elapsed");
            // Call your API here
        }

    }
}
