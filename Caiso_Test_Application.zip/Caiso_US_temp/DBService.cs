﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Caiso_US_temp
{
    public class DBService
    {
        public async static Task<DataTable> CallProcedure(string InXML)
        {
            // Retrieve the connection string from the configuration file
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

            // The DataTable to hold the results
            DataTable dataTable = new DataTable();

            // Establish the SQL connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    // Create the SqlCommand and set its properties
                    using (SqlCommand cmd = new SqlCommand("USP_PUT_InsertCallRecords", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;                       

                        // Add the input parameter and set its value
                        cmd.Parameters.Add(new SqlParameter("@InXML", SqlDbType.VarChar)).Value = InXML;

                        // Use SqlDataAdapter to fill the DataTable with the result set
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            adapter.Fill(dataTable);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }

                return dataTable;
            }
        }
    }
}
